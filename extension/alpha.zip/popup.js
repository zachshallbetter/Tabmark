    /**
 * popup.js
 * Author: Tyler Rigsby
 * Date: 6/12/2012
 *
 * Handles all the javascript related to the browser action popup. Includes all of the UI and most of the back-end
 * tab management work.
 *
 */

/**
 * On document ready, load the tasks from localStorage and put them in the popup view. Set event handlers.
 */
$(document).ready(function() {
    getUser(function(user) {
        LOGIN_URL = user.login;
        LOGOUT_URL = user.logout;
        var tasks = user.tasks;
        if (tasks) {
            setTasksView(tasks);
        }
        $("#save_task").click(function() {
            saveTask($("#task_name").val(), true);
        });
        $("#task_name").keypress(function(event) {
            if (event.which == 13) saveTask($("#task_name").val(), true);
        });
        $("#auto_update").click(setUpdate);
        $("#errors").addClass("ui-state-error ui-corner-all");
        $("#task_name").blur(function() {
            $("#task_name").focus();
            $("#errors").hide();
        });
        $("button").button();

        if (!user.email || user.email == "default") {
            var link = $("<a></a>");
            link.attr("href", LOGIN_URL);
            link.attr("target", "_blank");
            link.text("Log in");
            var span = $("<span></span>");
            span.append(link);
            span.append(" to enable cloud syncing");
            $("#username").append(span);
        } else {
            $("#username").append("Logged in as: " + user.email);
            $("#username").append("<br>")
            var link = $("<a></a>");
            link.attr("href", LOGOUT_URL);
            link.attr("target", "_blank");
            link.text("Log out");
            $("#username").append(link);
        }
    });
});

/**
 * Shows the error div in the popup with the specified message. This will disappear on the next click
 */

function showError(text) {
    $("#errors").html("");
    var icon = $("<span></span>");
    icon.addClass("ui-icon ui-icon-alert");
    $("#errors").show().append(icon).append(text);
}

/**
 * Recreates the accordion and makes it sortable again. Re-jquery-ifies the buttons. This is necessary after most
 * UI manipulations to keep things from breaking.
 */

function refreshAccordion() {
    $("#tasks").accordion('destroy').accordion({
        header: "> div > h3",
        collapsible: true,
        active: false,
        autoHeight: false
    }).sortable({
        axis: "y",
        handle: "h3",
        update: saveList
    });
    $("button").button();
}

/**
 * Persists the current list of tasks after an add/delete/reordering. Does not deal with the tabs themselves, just
 * modifies localStorage to reflect the current state of the UI.
 */

function saveList(event, ui) {
    getTasks(function(oldTasks) {
        var newTasks = [];
        var list = $(".task_name > a > span");
        $.each(list, function(i, val) {
            newTasks.push(oldTasks.slice(indexOfTask(oldTasks, $(val).html()))[0]);
        });
        setTasks(newTasks);
    });
}

/**
 * Clears and resets the list of tasks based on the passed 'tasks.'
 */

function setTasksView(tasks) {
    $("#tasks").html("");
    $.each(tasks, function(i, task) {
        if (task)
            addTaskView(task);
    });
}

/**
 * Adds an accordion element based on the specified task.
 */

function addTaskView(task) {
    var tabs = task.tabs;
    var update = task.update;
    var taskDiv = $("<div></div>");
    var taskContents = $("<div></div>");
    taskContents.addClass("task_contents");

    taskDiv.addClass("task");
    taskDiv.attr("id", "task_name_" + task.name);

    // create the tasks's title
    var h3 = $("<h3></h3>");
    h3.addClass("task_name");
    var nameAnchor = $("<a></a>");
    nameAnchor.attr("href", "#");
    var nameSpan = $("<span></span>");
    nameSpan.html(task.name);
    nameAnchor.append(nameSpan);
    h3.append(nameAnchor);
    taskDiv.append(h3);

    chrome.windows.getCurrent(null, function(window) {
        // display the element differently depending on if the current task is active in the current window.
        chrome.extension.sendRequest({
            type: "window_active",
            name: task.name,
            window: window.id
        }, function(response) {
            var ioAnchor = $("<a></a>");
            ioAnchor.addClass("io");
            if (response.response) {
                // if it is, add the Sync button and make the accordion say "Save" instead of "Load"
                taskDiv.addClass("active_task");
                if (update) $("#update_check").attr("checked", "checked");
                $("#update_check").attr("value", task.name);
                $("#update_check").button({
                    label: update ? "Sync Enabled" : "Sync Disabled"
                });
                $("#auto_update").show();
                ioAnchor.html("Save");
                ioAnchor.attr("href", "#active");
                ioAnchor.click(function() {
                    saveTask(task.name, false, true);
                    return false;
                });
            } else {
                // otherwise, show "Load"
                ioAnchor.html("Load");
                ioAnchor.click(function() {
                    loadTask(task);
                    return false;
                });
            }
            nameAnchor.append(ioAnchor);
        });
    });

    // Add the list of tabs with the text showing the title and the title/href showing the url. 
    var list = $("<ul></ul>");
    list.attr("class", "tablist");
    $.each(tabs, function(id, tab) {
        var li = $("<li></li>");
        var a = $("<a></a>");
        a.attr("href", tab.url);
        a.attr("target", "_blank");
        a.attr("title", tab.url);
        if (tab.title.length > 35) a.text(tab.title.substring(0, 35) + "...");
        else a.text(tab.title);
        li.append(a);
        list.append(li);
    });
    taskContents.append(list);

    // add a remove button to the inside of the task element.
    var removeButton = $("<button>Remove Task</button>");
    removeButton.addClass("ui-button-text");
    removeButton.click(function() {
        removeTask(task.name);
        return false;
    });
    taskContents.append(removeButton);

    taskDiv.append(taskContents);
    $("#tasks").append(taskDiv);
    refreshAccordion();
}

/**
 * event handler for removing a task. Accepts the name as a parameter. Finds the index of the task and removes it
 * from the UI and persisted state.
 */

function removeTask(name) {
    getUser(function(user) {
        var index = indexOfTask(user.tasks, name);
        user.tasks.splice(index, 1);
        setUser(user);
        var div = $("#task_name_" + name);
        if (div.hasClass("active_task")) {
            $("#auto_update").hide();
        }
        div.remove();
        setTasksView(user.tasks);
    });
}

/**
 * Loads the specified task in a new window.
 */

function loadTask(task) {
    var urls = new Array();
    $.each(task.tabs, function(id, tab) {
        urls.push(tab.url);
    });
    if (task.update)
        deleteTabsFromTask(task);
    chrome.windows.create({
        url: urls,
        focused: true
    }, function(window) {
        saveTask();
        addToUpdater(window, task.name);
    });
}

/**
 * Handler for when the active task's sync option is toggled. Changes the button state and whether the task is updated in the
 * persisted state.
 */

function setUpdate() {
    var checkbox = $("#update_check");
    var enabled = checkbox.attr("checked");
    getUser(function(user) {
        user.tasks[indexOfTask(user.tasks, checkbox.val())].update = enabled;
        $("#update_check").button("option", "label", enabled ? "Sync Enabled" : "Sync Disabled");
        setUser(user);
    });
}

/**
 * Notifies background.js that the task is active so that it will update the persisted state if it
 * is supposed to.
 */

function addToUpdater(window, name) {
    chrome.extension.sendRequest({
        type: "load_task",
        name: name,
        window: window.id,
    }, function() {});
}

/**
 * Stub abstracts the request to the background page. Takes a callback: myFun(tasks), tasks will be
 * the array of tasks, equivalent to localStorage["tasks"]
 */
function setUser(user, immediate) {
    chrome.extension.sendRequest({
        type: "set_user",
        user: user,
        immediate: immediate
    }, function() {});
}

function getUser(callback) {
    chrome.extension.sendRequest({
        type: "get_user"
    }, function(response) {
        callback(response);
    });
}

function deleteTabsFromTask(task) {
    chrome.extension.sendRequest({
        type: "delete_tabs",
        task: task
    }, function() {});   
}

/**
 * Saves a task with the specified name. If the task is new, makes a new Task for it, otherwise it updates
 * the old task with the specified name.
 */

function saveTask(name, isNew, immediate) {
    if (!name) {
        showError("Please enter a task name");
        return;
    }
    getUser(function(user) {
        if (!user.tasks) {
            user.tasks = [];
        }

        if (isNew && indexOfTask(tasks, name) >= 0) {
            showError("A task with that name already exists");
            return;
        } else {
            $("#task_name").attr("value", "");
        }

        chrome.windows.getCurrent({
            populate: true
        }, function(window) {
            var tabs = getTabsFromWindow(window);
            var task = isNew ? {
                name: escape(name),
                update: true
            } : user.tasks[indexOfTask(user.tasks, name)];
            task.tabs = tabs;
            if (isNew) {
                user.tasks.push(task);
                addToUpdater(window, name);
            }
            setTasksView(user.tasks);
            setUser(user, immediate);
        });
    });
}