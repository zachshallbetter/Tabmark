chrome.extension.sendMessage({
	type: "logged_in",
});
window.close();