chrome.extension.sendMessage({
	type: "reset",
});
window.close();