chrome.extension.sendMessage({
	type: "clear",
});
window.close();