chrome.extension.sendRequest({
	type: "logged_in",
});
// window.close();