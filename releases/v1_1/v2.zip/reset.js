chrome.extension.sendRequest({
	type: "reset",
});
window.close();