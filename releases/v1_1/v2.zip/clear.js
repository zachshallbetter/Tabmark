chrome.extension.sendRequest({
	type: "clear",
});
window.close();